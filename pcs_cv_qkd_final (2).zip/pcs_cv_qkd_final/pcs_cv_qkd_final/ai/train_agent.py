"""
ai/train_agent.py
=================
Training pipeline for ChannelLSTM shaping parameter predictor.

Generates realistic AR(1) fiber trajectories across varied channel conditions,
labels each block with the true ground-truth optimal nu* from optimal_nu(),
trains ChannelLSTM via Adam with Mean Squared Error loss,
and saves the trained weights to ai/lstm_weights.pt.
"""

from __future__ import annotations
import os
import sys
from pathlib import Path
import numpy as np

# Ensure root directory is in sys.path
ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from core.constellation import PCSConstellation
from core.key_rate import optimal_nu
from simulation.channel_env import ChannelEnvironment, EnvConfig
from ai.lstm_agent import ChannelLSTM, NuAgent


def generate_training_data(
    num_trajectories: int = 24,
    blocks_per_traj: int = 80,
    seq_len: int = 20,
    M: int = 256,
    N_block: int = 100_000_000,
    nu_el: float = 0.01,
    seed: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate (seq_len, 9) feature sequences and ground truth nu* labels."""
    print(f"[DataGen] Simulating {num_trajectories} channel trajectories...")
    rng = np.random.default_rng(seed)
    constellation = PCSConstellation(M)

    X_list: list[np.ndarray] = []
    y_list: list[float] = []

    # Distances in km: 8 to 44 km (positive key region)
    distances = np.linspace(8.0, 42.0, num_trajectories)

    for traj_idx, dist in enumerate(distances):
        # Channel transmittance: T = 10^(-0.2 * dist / 10)
        mu_T = float(10.0 ** (-0.2 * dist / 10.0))
        mu_xi = float(rng.uniform(0.003, 0.010))

        cfg = EnvConfig(
            mu_T=mu_T,
            mu_xi=mu_xi,
            sigma_T=float(rng.uniform(0.008, 0.016)),
            sigma_xi=float(rng.uniform(0.002, 0.004)),
        )
        step_at = int(rng.integers(25, 55)) if traj_idx % 2 == 1 else 999
        delta_xi = float(rng.uniform(0.010, 0.020)) if step_at < blocks_per_traj else 0.0

        env = ChannelEnvironment(cfg, seed=seed + traj_idx * 17)
        T_arr, xi_arr = env.run_trajectory(blocks_per_traj, step_change_at=step_at, delta_xi=delta_xi)

        agent = NuAgent(seq_len=seq_len, nu_min=0.5, nu_max=22.0)
        prev_skr = 0.0

        for t in range(blocks_per_traj):
            T_val = float(T_arr[t])
            xi_val = float(xi_arr[t])

            # Ground truth optimal nu* from grid optimizer
            nu_star_true, res_opt = optimal_nu(T_val, xi_val, nu_el, constellation, N_block, n_grid=120)

            snr_approx = T_val * constellation.modulation_variance(agent._prev_nu) / (1.0 + T_val * xi_val + nu_el)
            feat = agent._build_feature(T_val, xi_val, max(snr_approx, 0.01))
            agent.history.append(feat)

            if len(agent.history) == seq_len:
                seq = np.array(agent.history, dtype=np.float32)
                seq_norm = (seq - NuAgent.FEAT_MEAN) / (NuAgent.FEAT_STD + 1e-8)
                X_list.append(seq_norm)
                y_list.append(nu_star_true)

            agent._prev_skr = max(res_opt.skr_finite, 0.0)
            agent._prev_nu = nu_star_true

    X = np.array(X_list, dtype=np.float32)
    y = np.array(y_list, dtype=np.float32)
    print(f"[DataGen] Completed: Generated {len(X)} training sequences.")
    return X, y


def train_lstm(
    X: np.ndarray,
    y: np.ndarray,
    output_path: str = "ai/lstm_weights.pt",
    epochs: int = 50,
    batch_size: int = 32,
    lr: float = 1e-3,
    device: str = "cpu",
) -> None:
    """Train ChannelLSTM model and save weights."""
    print(f"[Training] Dataset: X={X.shape}, y={y.shape}")

    num_samples = len(X)
    indices = np.random.permutation(num_samples)
    split = int(0.85 * num_samples)
    train_idx, val_idx = indices[:split], indices[split:]

    train_ds = TensorDataset(torch.from_numpy(X[train_idx]), torch.from_numpy(y[train_idx]))
    val_ds = TensorDataset(torch.from_numpy(X[val_idx]), torch.from_numpy(y[val_idx]))

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    model = ChannelLSTM(input_dim=9, hidden1=128, hidden2=96, hidden3=64, hidden4=32, dense_dim=32, dropout=0.15)
    model.to(device)

    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=6)

    best_val_loss = float("inf")
    best_state = None

    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            optimizer.zero_grad()
            pred = model(batch_x)
            loss = criterion(pred, batch_y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * len(batch_x)
        train_loss /= len(train_ds)

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                pred = model(batch_x)
                loss = criterion(pred, batch_y)
                val_loss += loss.item() * len(batch_x)
        val_loss /= len(val_ds)
        scheduler.step(val_loss)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

        if epoch % 10 == 0 or epoch == epochs:
            print(f"[Epoch {epoch:02d}/{epochs}] Train MSE: {train_loss:.4f} | Val MSE: {val_loss:.4f} | Best: {best_val_loss:.4f}")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    torch.save(best_state, output_path)
    print(f"[Success] Saved trained LSTM weights to: {output_path} (Best Val MSE: {best_val_loss:.4f})")


if __name__ == "__main__":
    X, y = generate_training_data(num_trajectories=24, blocks_per_traj=80)
    target_path = os.path.join(os.path.dirname(__file__), "lstm_weights.pt")
    train_lstm(X, y, output_path=target_path, epochs=50)
